import java.sql.DriverManager;
import java.util.ArrayList;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nils
 */
public class LogIN_Check {
    Connection con;
    Statement st;
    ResultSet rs;
    DBConnect connect = new DBConnect();
    
    public ArrayList<User> getusersList(){
        ArrayList<User> usersList=new ArrayList<>();
        connect.DBConnect();
        
        String query="Select *From `clients`";
               
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost/Users?serverTimezone=Europe/Riga&useSSL=false","root","");
            st=con.createStatement();
             rs = st.executeQuery(query);
             User user;
             while(rs.next()){
                 user=new User(rs.getInt("id"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("email"),rs.getString("password"));
                 usersList.add(user);
             }

        }catch (Exception ex){
            ex.printStackTrace();
        }
       return usersList;
    }
    
     public ArrayList<User> getAdminList(){
        ArrayList<User> AdminList=new ArrayList<>();
        connect.DBConnect();
        
        String query="Select *From `admin`";
               
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost/Users?serverTimezone=Europe/Riga&useSSL=false","root","");
            st=con.createStatement();
             rs = st.executeQuery(query);
             User admin;
             while(rs.next()){
                 admin=new User(rs.getInt("id"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("email"),rs.getString("password"));
                 AdminList.add(admin);
             }

        }catch (Exception ex){
            ex.printStackTrace();
        }
       return AdminList;
    }
    
    
    
    
    public boolean LogIN_Check_Clients(double id,String Password) throws NoSuchAlgorithmException{
            checks checks=new checks();
            ArrayList<User> list = getusersList();
            Password=checks.passwordMD(Password);
            
            for (int i=0;i<list.size();i++){
                   if ((Password.equals(list.get(i).getPassword())) && (id==list.get(i).getID()))
                       return true;
            }
        return false;
    }
      public boolean LogIN_Check_Admin(double id,String Password) throws NoSuchAlgorithmException{
            checks checks=new checks();
            ArrayList<User> list = getAdminList();
            Password=checks.passwordMD(Password);
            
            for (int i=0;i<list.size();i++){
                   if ((Password.equals(list.get(i).getPassword())) && (id==list.get(i).getID()))
                       return true;
            }
        return false;
    }
}
