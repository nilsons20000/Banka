/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nils
 */


public class SuperAdmin {
    Admin_panel panel=new  Admin_panel();
    DBConnect connect = new DBConnect();

    
    public String Insert_Admin(String name_INPUT,String lastName_INPUT,String email_INPUT,String password_INPUT){
        String query;
        query = "INSERT INTO `users`.`admin`(`firstName`, `lastName`, `email`,`password`) VALUES ('"+name_INPUT+"','"+lastName_INPUT+"','"+email_INPUT+"','"+password_INPUT+"')";
        return query;
    }
    public String Insert_clients(String name_INPUT,String lastName_INPUT,String email_INPUT,String password_INPUT){
        String query;
        query = "INSERT INTO `users`.`clients`(`firstName`, `lastName`, `email`,`password`) VALUES ('"+name_INPUT+"','"+lastName_INPUT+"','"+email_INPUT+"','"+password_INPUT+"')";
        return query;
       
    }

    public String Delete_clients(String ID){
        String query="DELETE FROM `users`.`clients` WHERE id="+ID;
        return query;
    }
    public void Delete_admin(String ID){
        String query="DELETE FROM `users`.`admin` WHERE id="+ID;
        panel.executeSQLQuery(query,"Deleted");
    }
    
    public String Update_clients(String name_INPUT,String lastName_INPUT,String email_INPUT,String password_INPUT,String ID){
        String query = "UPDATE `users`.`clients` SET `firstName`='"+name_INPUT+"',`lastName`='"+lastName_INPUT+"',`email`='"+email_INPUT+"',`password`='"+password_INPUT+"' WHERE id = "+ID;
        return query;
    }
    
}
