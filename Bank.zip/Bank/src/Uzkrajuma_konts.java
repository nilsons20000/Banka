
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nils
 */
public class Uzkrajuma_konts extends Konti{
 private Connection con;
    private Statement st;
    private ResultSet rs;


    public String Insert_Uzkrajuma_Kont(String ID,String Konta_numurs,int Balance){
        String query;
        query = "INSERT INTO `konti`.`uzkrajuma`(`id`, `Konta_numurs`, `Balance`) VALUES ('"+ID+"','"+Konta_numurs+"','"+Balance+"')";
        return query;
       
    }
       public boolean hasKreditaKonts(String temp)   {
        try{
               con = DriverManager.getConnection("jdbc:mysql://localhost/konti?serverTimezone=Europe/Riga&useSSL=false","root","");
               st=con.createStatement();
                String Kredita_konts =temp ;
                String sql = "SELECT * FROM uzkrajuma WHERE Konta_numurs= ?";
                PreparedStatement preparedStatement =con.prepareStatement(sql);
                preparedStatement.setString(1, Kredita_konts);
                ResultSet rs = preparedStatement.executeQuery();
        return rs.next();
            }catch(SQLException ex){
                ex.printStackTrace();

            }   
        return false;
    }
}
