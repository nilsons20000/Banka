
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;




/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nils
 */
public class NewMain {

    /**
     * @param args the command line arguments
     * @throws java.security.NoSuchAlgorithmException
     */
    public static void main(String[] args) throws NoSuchAlgorithmException {
        checks z= new checks();
        
        if(z.isValidEmailAddress())
            System.out.print("OK");
        else
            System.out.print("Err");
    }
    
}
