/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nils
 */
public class Algas_konts extends Konti{

     public String Insert_Algas_Kont(String name_INPUT,String lastName_INPUT,String email_INPUT,String password_INPUT){
        String query;
        query = "INSERT INTO `users`.`clients`(`firstName`, `lastName`, `email`,`password`) VALUES ('"+name_INPUT+"','"+lastName_INPUT+"','"+email_INPUT+"','"+password_INPUT+"')";
        return query;
       
    }
}
